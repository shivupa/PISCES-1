// read a MOLDEN file and convert one of the orbitals to a cube file
#include <stdio.h>
#include <stdlib.h>
#include <math.h>
#include <string.h>
#include <ctype.h>
#include <unistd.h>
#include <iostream>
using namespace std;

#include "tsin.h"

const int LineLen = 132;
const int MaxNuc   = 200;
const int MaxShell = 400;

struct nucleus {
  double x;
  double y;
  double z;
  int q;
  char lbl[8];
};

struct shell {
  int center;  // index of the nucleus
  int l;       // angular momentum
  int npr;     // number of primitive GTOs
  double *a;   // exponents
  double *c;   // contraction coefficients
  double *nrm;  // normalization factors for each primitive GTO
};


const double PI = 3.14159265358979;
const double OOPI3 = 1.0 / (PI * PI * PI);



int main(int argc, char* argv[])
{
  cout << "\nWelcome to Molden2Cube\n";

  if (argc != 2)  {
    cout << "usage: mol2cube input-file\n";
    exit(1);
  }

  //
  //    read input: MOLDEN file, orbital number, and grid parameters
  //
  class TSIN Input;
  cout << "\nThis is the Input read from " << argv[1] << ":\n";
  Input.ReadFromFile(argv[1], 5);

  int verbose = Input.GetInt("Input", "Verbose", 1);
  int orbital = Input.GetInt("Input", "Orbital", 1);
  char *fnmolden; 
  char *fncube; 
  Input.GetString("Input", "MoldenFile", "MOLDEN", &fnmolden);
  Input.GetString("Input", "CubeFile", "Cube.cub", &fncube);

  cout << "MOLDEN: " << fnmolden << endl;
  cout << "Cube  : " << fncube << endl;

  // Grid parameters
  double xmin = Input.GetDouble("Input", "Xmin", 0.0);
  double ymin = Input.GetDouble("Input", "Ymin", 0.0);
  double zmin = Input.GetDouble("Input", "Zmin", 0.0);
  double xmax = Input.GetDouble("Input", "Xmax", 0.0);
  double ymax = Input.GetDouble("Input", "Ymax", 0.0);
  double zmax = Input.GetDouble("Input", "Zmax", 0.0);
  int xsteps  = Input.GetInt("Input", "XSteps", 0);
  int ysteps  = Input.GetInt("Input", "YSteps", 0);
  int zsteps  = Input.GetInt("Input", "ZSteps", 0);

  // this is for simple xy, xz, and yz grids
  // grid or cube?
  int grid = 0;
  double dx = 0, dy = 0, dz = 0;
  if (xsteps == 0) 
    grid = 1;
  else
    dx = (xmax - xmin) / double(xsteps);
  if (ysteps == 0) 
    grid = 1;
  else  
    dy = (ymax - ymin) / double(ysteps);
  if (zsteps == 0) 
    grid = 1;
  else
    dz = (zmax - zmin) / double(zsteps);


  //
  //  this is for a more general 2D grid or cut
  //  X = n*A + m*B + C
  //
  double Va[3] = {1,0,0}, Vb[3] = {0,1,0}, Vc[3] = {0,0,0};
  int nMin = -20, nMax = 20, mMin = -20, mMax = 20;
  int GenGrid = Input.GetInt("Input", "GeneralGrid", 0);
  if (GenGrid == 1) {
    cout << "Reading General-Grid input\n";
    Input.GetDoubleArray("Input", "VecA", Va, 3);
    Input.GetDoubleArray("Input", "VecB", Vb, 3);
    Input.GetDoubleArray("Input", "VecC", Vc, 3);
    nMin = Input.GetInt("Input", "nMin", -20);
    nMax = Input.GetInt("Input", "nMax",  20);
    mMin = Input.GetInt("Input", "mMin", -20);
    mMax = Input.GetInt("Input", "mMax",  20);
  }
  cout << "Cube2  : " << fncube << endl;
  //  open the MOLDEN file
  cout << "Reading " << fnmolden << "\n";
  FILE *molden;
  if ((molden = fopen(fnmolden,"r")) == 0) {
    printf("Error opening %s\n", fnmolden);
    exit(1);
  }

  cout << "Cube3  : " << fncube << endl;
  int line = 0;
  char *buffer = new char[LineLen];
  cout << "Cube4  : " << fncube << endl;

  strcpy (buffer, " ");


  // look for [ATOMS]
  cout << "Looking for [ATOMS]\n";
  while (strstr(buffer, "[ATOMS]") == 0) {
    line ++;
    if (fgets(buffer, LineLen, molden) == 0)
      {printf("Error reading line %i while looking for [ATOMS]\n>>%s<<\n", line, buffer); exit(1);}
  }
  double scale = 0;
  if (strstr(buffer, "ANG")) {
    scale = 1 / 0.52917720859;
    cout << "Atomic coordinates in Angstrom\n";
  }
  else {
    scale = 1;
    cout << "Atomic coordinates in Bohr\n";
  }

  cout << "Cube  : " << fncube << endl;

  // now read the atoms
  int natoms = 0;
  int k;
  struct nucleus atom[MaxNuc];
  while (1) {
    int idx;
    line ++;
    if (fgets(buffer, LineLen, molden) == 0)
      {printf("Error reading line %i while reading the atomic coordiantes\n", line); exit(1);}
    if (strstr(buffer, "["))
      break;
    if (sscanf(buffer, "%s  %i %i %lf %lf %lf", 
	       atom[natoms].lbl, &idx, &atom[natoms].q, 
	       &atom[natoms].x, &atom[natoms].y, &atom[natoms].z) != 6)
      {printf("Error scaning line %i while reading the atomic coordiantes\n", line); exit(1);}
    printf("%s", buffer);
    printf("%f %f %f\n", atom[natoms].x, atom[natoms].y, atom[natoms].z);
    natoms ++;
    if (natoms == MaxNuc)
      {printf("Too many atoms (%i). Change MaxNuc and recompile.\n", natoms); exit(1);}
  }
  for (k = 0; k < natoms; ++k) {
    atom[k].x *= scale;
    atom[k].y *= scale;
    atom[k].z *= scale;
  }
  if (verbose > 0)
    cout << natoms << " atoms have been read\n"; 

  // start writing the output file (cube or grid)
  FILE *cube;
  cout << "Cube  : " << fncube << endl;


  cube = fopen(fncube, "w+");
  if (grid == 0) {
    fprintf(cube, " 8 0\n");  // this is going to be an orbital not a density
    fprintf(cube, " 1e-2 3e-3 1e-3 3e-4 1e-4 3e-5 1e-5 3e-6\n");
    fprintf(cube, "%5i  %11.6f  %11.6f  %11.6f\n", natoms, xmin, ymin, zmin);
    fprintf(cube, "%5i  %11.6f  %11.6f  %11.6f\n", xsteps+1, dx, 0.0, 0.0);
    fprintf(cube, "%5i  %11.6f  %11.6f  %11.6f\n", ysteps+1, 0.0, dy, 0.0);
    fprintf(cube, "%5i  %11.6f  %11.6f  %11.6f\n", zsteps+1, 0.0, 0.0, dz);
    for (k = 0; k < natoms; ++k)
      fprintf(cube, "%3i   0  %11.6f  %11.6f  %11.6f\n", 
	      atom[k].q, atom[k].x, atom[k].y, atom[k].z);
  }

  // look for [GTO]
  cout << "Looking for [GTO]\n";
  while (strstr(buffer, "[GTO]") == 0) {
    line ++;
    if (fgets(buffer, LineLen, molden) == 0)
      {printf("Error reading line %i while looking for [GTO]\n>>%s<<\n", line, buffer); exit(1);}
  }

  // read the GTOs
  struct shell basis[MaxShell];
  int nshells = 0; 
  int ncenter = 0;
  int ngtos = 0;
  char ll[3];  // s, p, d, ..., but maybe sp
  double aa, cc;
  while (1) {
    line ++;
    if (fgets(buffer, LineLen, molden) == 0)
      {printf("Error reading the basis set in line %i\n>>%s<<\n", line, buffer); exit(1);}
    if (strstr(buffer, "["))
      break;
    else {
      if (sscanf(buffer, "%i", &ncenter) != 1)
	{printf("Error getting basis set center in line %i\n>>%s<<\n", line, buffer); exit(1);}
      while (1) {
	line ++;
	if (fgets(buffer, LineLen, molden) == 0)
	  {printf("Error reading gtos in line %i\n>>%s<<\n", line, buffer); exit(1);}
	if (sscanf(buffer, "%s %i", ll, &ngtos) != 2)
	  break;
	basis[nshells].center = ncenter - 1;
	if (strlen(ll) > 1)
	  {printf("Sorry, only simple shells : line %i\n>>%s<<\n", line, buffer); exit(1);}
	switch (ll[0]) 
	  {
	  case 's' : basis[nshells].l = 0; break;
	  case 'p' : basis[nshells].l = 1; break;
	  case 'd' : basis[nshells].l = 2; break;
	  case 'f' : basis[nshells].l = 3; break;
	  default  : printf("Only s, p, d, and f functions so far : line %i\n>>%s<<\n", line, buffer); 
	    exit(1);
	    break;
	  }
	basis[nshells].a = new double[ngtos];
	basis[nshells].c = new double[ngtos];
	if (verbose > 1)
	  printf("Reading a %s shell with %i primitives on center %i\n", ll, ngtos, ncenter);
	int kpr = 0; // ignore primitives with 0 contraction coefficient
	for (int ipr = 0; ipr < ngtos; ++ ipr) {
	  line ++;
	  if (fgets(buffer, LineLen, molden) == 0)
	    {printf("Error reading primitive line %i\n>>%s<<\n", line, buffer); exit(1);}
	  if (sscanf(buffer, "%lf %lf", &aa, &cc) != 2)
	    {printf("Error reading exp and coef in line %i\n>>%s<<\n", line, buffer); exit(1);}
	  if (fabs(cc) > 1e-30) {
	    basis[nshells].a[kpr] = aa;
	    basis[nshells].c[kpr] = cc;
	    kpr ++;
	  }
	}
	basis[nshells].npr = kpr;
	nshells++;
      }
    }
  }
  cout << nshells << " shells have been read\n";

  // compute normalization factors of primitive GTOs
  int ishell;
  for (ishell = 0; ishell < nshells; ++ ishell) {
    basis[ishell].nrm = new double[basis[ishell].npr];
    for (int iprm = 0; iprm < basis[ishell].npr; ++iprm) {
      // this follows the convention used when Aces2 or CFour write MOLDEN files
      // all components of a shell have the same "normalization" factor
      // the differences between, say, d_xx and d_xy, are absorbed in the MO coefficients
      switch (basis[ishell].l)
      {
      case 0 : basis[ishell].nrm[iprm] = pow((8.0     * pow(basis[ishell].a[iprm], 3)*OOPI3), 0.25); break;
      case 1 : basis[ishell].nrm[iprm] = pow((128.0   * pow(basis[ishell].a[iprm], 5)*OOPI3), 0.25); break;
      case 2 : basis[ishell].nrm[iprm] = pow((2048.0  * pow(basis[ishell].a[iprm], 7)*OOPI3), 0.25); break;
      case 3 : basis[ishell].nrm[iprm] = pow((32768.0 * pow(basis[ishell].a[iprm], 9)*OOPI3), 0.25); break;
	// this is the normalization for xx; for xy multiply with sqrt(3)
	//      case 2 : basis[ishell].nrm[iprm] = pow((2048.0/9.0 * pow(basis[ishell].a[iprm], 7)*OOPI3), 0.25);
	// 	basis[ishell].nrm[iprm] *= sqrt(3.0);  // for Aces Molden file coefficient convention
	//      break;
      default:
	cout << "This should never happen.\n";
	exit(1);
	break;
      }
    }
  }

  // compute length of an MO vector
  ngtos = 0;
  for (ishell = 0; ishell < nshells; ++ ishell)
    switch (basis[ishell].l)
      {
      case 0 : ngtos +=  1; break;
      case 1 : ngtos +=  3; break;
      case 2 : ngtos +=  6; break;
      case 3 : ngtos += 10; break;
      default:
	cout << "This should never happen.\n";
	exit(1);
	break;
      }
  cout << "The basis set consists of " << ngtos << " GTOs.\n";
  double *cmo = new double[ngtos]; 

  // look for [MO]
  cout << "Looking for [MO]\n";
  while (strstr(buffer, "[MO]") == 0) {
    line ++;
    if (fgets(buffer, LineLen, molden) == 0)
      {printf("Error reading line %i while looking for [MO]\n>>%s<<\n", line, buffer); exit(1);}
  }

  // ignore first orbital-1 MOs
  for (int iorb = 1; iorb < orbital; ++iorb) {
    for (k = 0; k < ngtos+4; ++k) {
      line ++;
      if (fgets(buffer, LineLen, molden) == 0)
	{printf("Error reading line %i while ignoring MO %i\n", line, iorb); exit(1);}  
    }
  }

  // read the orbital-th MO
  cout << "Orbital number " << orbital << endl;
  for (k = 0; k < 4; ++k) {
    line ++;
    if (fgets(buffer, LineLen, molden) == 0)
      {printf("Error reading line %i of MO %i header\n", line, orbital); exit(1);}  
    cout << buffer;
  }
  for (k = 0; k < ngtos; ++k) {
    line ++;
    if (fgets(buffer, LineLen, molden) == 0)
      {printf("Error reading line %i MO coefficient %i\n", line, k); exit(1);}  
    if (sscanf(buffer, "%*i %lf", &cmo[k]) != 1)
      {printf("Error (line %i) reading MO coefficient %i\n", line, k); exit(1);} 
  }
  
  fclose(molden);


  // compute the wavefunction at all atoms
  {

    printf("\nAmplitude at the atoms:\n");

    for (int iatom = 0; iatom < natoms; ++iatom) {

      double x = atom[iatom].x;
      double y = atom[iatom].y;
      double z = atom[iatom].z;
	  
      double phi = 0;
      int moidx = 0;
      for (ishell = 0; ishell < nshells; ++ishell) {
	int inuc = basis[ishell].center;
	double delx = x - atom[inuc].x;
	double dely = y - atom[inuc].y;
	double delz = z - atom[inuc].z;
	double r2 = delx*delx + dely*dely + delz*delz;
	
	double expfac = 0;
	for (int iprm = 0; iprm < basis[ishell].npr; ++iprm) {
	  //
	  //  this absorbes, e.g., the d_xy/d_xx normalization quotient in the d_xy MO coefficient!
	  //
	  expfac += basis[ishell].nrm[iprm] * basis[ishell].c[iprm] * exp(-basis[ishell].a[iprm]*r2);
	}
	// see MOLDEN format
	switch (basis[ishell].l)
	  {
	  case 0: 
	    phi += cmo[moidx] * expfac; 
	    moidx += 1;
	    break;
	  case 1: 
	    phi += (cmo[moidx]   * delx + 
		    cmo[moidx+1] * dely + 
		    cmo[moidx+2] * delz) * expfac; 
	    moidx += 3;
	    break;
	  case 2: 
	    phi += (cmo[moidx]   * delx * delx + 
		    cmo[moidx+1] * dely * dely + 
		    cmo[moidx+2] * delz * delz +
		    cmo[moidx+3] * delx * dely + 
		    cmo[moidx+4] * delx * delz + 
		    cmo[moidx+5] * dely * delz) * expfac; 
	    moidx += 6;
	    break;
	  case 3: 
	    phi += (cmo[moidx]   * delx * delx * delx + 
		    cmo[moidx+1] * dely * dely * dely + 
		    cmo[moidx+2] * delz * delz * delz +
		    cmo[moidx+3] * delx * dely * dely + 
		    cmo[moidx+4] * delx * delx * dely + 
		    cmo[moidx+5] * delx * delx * delz + 
		    cmo[moidx+6] * delx * delz * delz + 
		    cmo[moidx+7] * dely * delz * delz + 
		    cmo[moidx+8] * dely * dely * delz + 
		    cmo[moidx+9] * delx * dely * delz) * expfac; 
	    moidx += 10;
	    break;
	  default:
	    cout << "This should never happen.\n"; exit(1); break;
	  }
      }

      printf("%s  %13.5e,  (%13.7f,  %13.7f,  %13.7f)\n", atom[iatom].lbl, phi, x, y, z);

      
    }
    printf("\n");
  }







  // compute the wavefunction on the grid
  if (GenGrid == 0) {
    int i5 = 1;
    double intr = 0;
    double dV = dx*dy*dz; 
    for (int ix = 0; ix <= xsteps; ++ix) {
      cout << "Doing plane #" << ix;
      double x = xmin + double(ix)*dx;
      for (int iy = 0; iy <= ysteps; ++iy) {
	double y = ymin + double(iy)*dy;
	for (int iz = 0; iz <= zsteps; ++iz) {
	  double z = zmin + double(iz)*dz;
	  
	  double phi = 0;
	  int moidx = 0;
	  for (ishell = 0; ishell < nshells; ++ishell) {
	    int inuc = basis[ishell].center;
	    double delx = x - atom[inuc].x;
	    double dely = y - atom[inuc].y;
	    double delz = z - atom[inuc].z;
	    double r2 = delx*delx + dely*dely + delz*delz;
	    
	    double expfac = 0;
	    for (int iprm = 0; iprm < basis[ishell].npr; ++iprm) {
	      //
	      //  this absorbes, e.g., the d_xy/d_xx normalization quotient in the d_xy MO coefficient!
	      //
	      expfac += basis[ishell].nrm[iprm] * basis[ishell].c[iprm] * exp(-basis[ishell].a[iprm]*r2);
	    }
	    // see MOLDEN format
	    switch (basis[ishell].l)
	      {
	      case 0: 
		phi += cmo[moidx] * expfac; 
		moidx += 1;
		break;
	      case 1: 
		phi += (cmo[moidx]   * delx + 
			cmo[moidx+1] * dely + 
			cmo[moidx+2] * delz) * expfac; 
		moidx += 3;
		break;
	      case 2: 
		phi += (cmo[moidx]   * delx * delx + 
			cmo[moidx+1] * dely * dely + 
			cmo[moidx+2] * delz * delz +
			cmo[moidx+3] * delx * dely + 
			cmo[moidx+4] * delx * delz + 
			cmo[moidx+5] * dely * delz) * expfac; 
		moidx += 6;
		break;
	      case 3: 
		phi += (cmo[moidx]   * delx * delx * delx + 
			cmo[moidx+1] * dely * dely * dely + 
			cmo[moidx+2] * delz * delz * delz +
			cmo[moidx+3] * delx * dely * dely + 
			cmo[moidx+4] * delx * delx * dely + 
			cmo[moidx+5] * delx * delx * delz + 
			cmo[moidx+6] * delx * delz * delz + 
			cmo[moidx+7] * dely * delz * delz + 
			cmo[moidx+8] * dely * dely * delz + 
			cmo[moidx+9] * delx * dely * delz) * expfac; 
		moidx += 10;
		break;
	      default:
		cout << "This should never happen.\n"; exit(1); break;
	      }
	  }
	  if (grid == 0) {
	    fprintf(cube, "%13.5e ", phi);
	    if (i5 % 6  == 0)
	      fprintf(cube, "\n");
	    i5 ++;
	  }
	  else {
	    fprintf(cube, "%13.7f  %13.7f  %13.7f   %15.7e\n", x, y, z, phi);
	  }
	  intr += phi*phi;
	  

	}
	if (grid == 1 && zsteps > 0) fprintf(cube, "\n");
      }
      if (grid == 1 && zsteps == 0) fprintf(cube, "\n");
      printf("  Int d3r phi**2 = %11.4e\n", intr*dV);
    }
  }
  //
  //  general grid
  //
  else {
    cout << "GenGrid stepping\n";
    for (int n = nMin; n <= nMax; ++n) {
      for (int m = mMin; m <= mMax; ++m) {
	
	  double x = n*Va[0] + m*Vb[0] + Vc[0];
	  double y = n*Va[1] + m*Vb[1] + Vc[1];
	  double z = n*Va[2] + m*Vb[2] + Vc[2];

	  double phi = 0;
	  int moidx = 0;
	  for (ishell = 0; ishell < nshells; ++ishell) {
	    int inuc = basis[ishell].center;
	    double delx = x - atom[inuc].x;
	    double dely = y - atom[inuc].y;
	    double delz = z - atom[inuc].z;
	    double r2 = delx*delx + dely*dely + delz*delz;
	    
	    double expfac = 0;
	    for (int iprm = 0; iprm < basis[ishell].npr; ++iprm) {
	      //
	      //  this absorbes, e.g., the d_xy/d_xx normalization quotient in the d_xy MO coefficient!
	      //
	      expfac += basis[ishell].nrm[iprm] * basis[ishell].c[iprm] * exp(-basis[ishell].a[iprm]*r2);
	    }
	    // see MOLDEN format
	    switch (basis[ishell].l)
	      {
	      case 0: 
		phi += cmo[moidx] * expfac; 
		moidx += 1;
		break;
	      case 1: 
		phi += (cmo[moidx]   * delx + 
			cmo[moidx+1] * dely + 
			cmo[moidx+2] * delz) * expfac; 
		moidx += 3;
		break;
	      case 2: 
		phi += (cmo[moidx]   * delx * delx + 
			cmo[moidx+1] * dely * dely + 
			cmo[moidx+2] * delz * delz +
			cmo[moidx+3] * delx * dely + 
			cmo[moidx+4] * delx * delz + 
			cmo[moidx+5] * dely * delz) * expfac; 
		moidx += 6;
		break;
	      case 3: 
		phi += (cmo[moidx]   * delx * delx * delx + 
			cmo[moidx+1] * dely * dely * dely + 
			cmo[moidx+2] * delz * delz * delz +
			cmo[moidx+3] * delx * dely * dely + 
			cmo[moidx+4] * delx * delx * dely + 
			cmo[moidx+5] * delx * delx * delz + 
			cmo[moidx+6] * delx * delz * delz + 
			cmo[moidx+7] * dely * delz * delz + 
			cmo[moidx+8] * dely * dely * delz + 
			cmo[moidx+9] * delx * dely * delz) * expfac; 
		moidx += 10;
		break;
	      default:
		cout << "This should never happen.\n"; exit(1); break;
	      }
	  }
	  fprintf(cube, "%13.7f  %13.7f  %13.7f   %15.7e\n", x, y, z, phi);	  
      }
      fprintf(cube, "\n");
    }
  }

  


  cout << "Done.\n";

  fclose(cube);


  exit(0);
}


