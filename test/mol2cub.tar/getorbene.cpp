//
// read a MOLDEN file and reorder the wrong Aces order of the
// d (and f) coefficients
//
#include <stdio.h>
#include <stdlib.h>
#include <math.h>
#include <string.h>
#include <ctype.h>
#include <unistd.h>
#include <iostream>
using namespace std;

const int LineLen = 132;
const double AU2EV  = 27.21138386;

FILE *molden;

char buffer[LineLen];


int main(int argc, char* argv[])
{
  if (argc < 2 || argc > 4)  {
    cout << "\nGet orbital energies from a MOLDEN file\n";
    cout << "usage: getorbene MOLDEN-file [nFrom] [nTo]\n";
    exit(1);
  }

  // input file
  char *fnmolden = argv[1]; 
  if ((molden = fopen(fnmolden,"r")) == 0) {
    printf("Error opening %s\n", fnmolden);
    exit(1);
  }
  
  // orbital range
  int nFrom = 0;
  int nTo = 30;

  if (argc > 2)
    nFrom = atoi(argv[2]);
  if (argc > 3)
    nTo = atoi(argv[3]);

  int nLine = 0;
  int nEne = 0;
  double ene = 0;

  while (fgets(buffer, LineLen, molden) != 0)
    {
      nLine ++;

      if (strstr(buffer, "Ene=")) {
	nEne += 1;
	int ngot = sscanf(buffer, " Ene= %lf", &ene);
	if (ngot != 1)
	{
	  cout << "Error reading line " << nLine << " ngot= " << ngot << "\n";
	  cout << ene << "\n";
	  cout << buffer;
	  exit(42);
	}
	if (nEne >= nFrom)
	  cout << " " << ene*AU2EV;
	if (nEne == nTo)
	  break;
      }
    }


  if (nEne != nTo)
    cout << " Warning; only " << nEne << " energies found.";
  cout << "\n";
  fclose(molden);
  exit(0);

}

