//
// read a MOLDEN file and reorder the wrong Aces order of the
// d (and f) coefficients
//
#include <stdio.h>
#include <stdlib.h>
#include <math.h>
#include <string.h>
#include <ctype.h>
#include <unistd.h>
#include <iostream>
using namespace std;

const int LineLen = 132;
const int MaxNuc   = 200;
const int MaxShell = 400;

struct nucleus {
  double x;
  double y;
  double z;
  int q;
  char lbl[8];
};

struct shell {
  int center;  // index of the nucleus
  int l;       // angular momentum
  int npr;     // number of primitive GTOs
  double *a;   // exponents
  double *c;   // contraction coefficients
  double *nrm;  // normalization factors for each primitive GTO
};


const double PI = 3.14159265358979;
const double OOPI3 = 1.0 / (PI * PI * PI);


int line = 0;

FILE *molden;
FILE *out;

int nshells = 0; 
int ngtos = 0;

char buffer[LineLen];

struct shell basis[MaxShell];

void GetBasis(void);
void ReorderMOs(void);



int main(int argc, char* argv[])
{
  cout << "\nWelcome to Reorder: Aces created MOLDEN to correct MOLDEN format\n";
  if (argc != 2)  {
    cout << "usage: reorder aces-created-MOLDEN-file\n";
    exit(1);
  }

  // input file
  char *fnmolden = argv[1]; 
  cout << "Reading " << fnmolden << "\n";
  if ((molden = fopen(fnmolden,"r")) == 0) {
    printf("Error opening %s\n", fnmolden);
    exit(1);
  }
  
  // output file
  sprintf(buffer, "%s.rod", fnmolden);
  cout << "Writing " << buffer << "\n";
  out = fopen(buffer, "w");


  int HaveBasis = 0;

  while (fgets(buffer, LineLen, molden) != 0)
    {
      line ++;
      fprintf(out, "%s", buffer);

    checkbrac:

      if (strstr(buffer, "[5D]")) {
	cout << "Error in line " << line << "\n";
	cout << "Aces writes only cartesian output, I think ...\n";
	exit(1);
      }
      else if (strstr(buffer, "[GTO]")) {
	if (HaveBasis != 0) {
	  cout << "Error in line " << line << "\n";
	  cout << "Found a second [GTO] set.\n";
	  exit(1);
	}
	GetBasis();
	HaveBasis = 1;
	goto checkbrac;
      }
      else if (strstr(buffer, "[MO]")) {
	if (HaveBasis == 0) {
	  cout << "Error in line " << line << "\n";
	  cout << "Found an MO, but have no basis set yet.\n";
	  exit(1);
	}
	ReorderMOs();
	goto checkbrac;
      }
    }

  fclose(molden);
  fclose(out);
  exit(0);

}


////////////////////////////////////////////////////////////////////////////////

void GetBasis(void)
{
  int verbose = 1;

  // is called after [GTO] has been found
  char ll[3];  // s, p, d, ..., but maybe sp
  double aa, cc;
  int ncenter = 0;

  while (1) {
    line ++;
    if (fgets(buffer, LineLen, molden) == 0)
      {printf("Error reading the basis set in line %i\n>>%s<<\n", line, buffer); exit(1);}
    fprintf(out, "%s", buffer);   
    if (strstr(buffer, "["))
      break;
    else {
      if (sscanf(buffer, "%i 0", &ncenter) != 1)
	{printf("Error getting basis set center in line %i\n>>%s<<\n", line, buffer); exit(1);}
      while (1) {
	line ++;
	if (fgets(buffer, LineLen, molden) == 0)
	  {printf("Error reading gtos in line %i\n>>%s<<\n", line, buffer); exit(1);}
	fprintf(out, "%s", buffer);
	if (sscanf(buffer, "%s %i", ll, &ngtos) != 2)
	  break;
	basis[nshells].center = ncenter - 1;
	if (strlen(ll) > 1)
	  {printf("Sorry, only simple shells : line %i\n>>%s<<\n", line, buffer); exit(1);}
	switch (ll[0]) 
	  {
	  case 's' : basis[nshells].l = 0; break;
	  case 'p' : basis[nshells].l = 1; break;
	  case 'd' : basis[nshells].l = 2; break;
	  case 'f' : basis[nshells].l = 3; break;
	  default  : printf("Only s, p, d functions so far : line %i\n>>%s<<\n", line, buffer); 
	    exit(1);
	    break;
	  }
	basis[nshells].a = new double[ngtos];
	basis[nshells].c = new double[ngtos];
	if (verbose > 1)
	  printf("Reading a %s shell with %i primitives on center %i\n", ll, ngtos, ncenter);
	int kpr = 0; // ignore primitives with 0 contraction coefficient
	for (int ipr = 0; ipr < ngtos; ++ ipr) {
	  line ++;
	  if (fgets(buffer, LineLen, molden) == 0)
	    {printf("Error reading primitive line %i\n>>%s<<\n", line, buffer); exit(1);}
	  fprintf(out, "%s", buffer);
	  if (sscanf(buffer, "%lf %lf", &aa, &cc) != 2)
	    {printf("Error reading exp and coef in line %i\n>>%s<<\n", line, buffer); exit(1);}
	  if (fabs(cc) > 1e-30) {
	    basis[nshells].a[kpr] = aa;
	    basis[nshells].c[kpr] = cc;
	    kpr ++;
	  }
	}
	basis[nshells].npr = kpr;
	nshells++;
      }
    }
  }
  cout << nshells << " shells have been read\n";

  // compute length of an MO vector
  ngtos = 0;
  for (int ishell = 0; ishell < nshells; ++ ishell)
    switch (basis[ishell].l)
      {
      case 0 : ngtos +=  1; break;
      case 1 : ngtos +=  3; break;
      case 2 : ngtos +=  6; break;
      case 3 : ngtos += 10; break;
      default:
	cout << "This should never happen.\n";
	exit(1);
	break;
      }
  cout << "The basis set consists of " << ngtos << " GTOs.\n";

}


//////////////////////////////////////////////////////////////////////////////////////

void ReorderMOs(void) {

  // called after "[MO]" was found

  //  double sqr3 = sqrt(3.0);

  int nmos = 0;
  int k = 0;

  int bflag = 0;

  double *vec = new double[ngtos];

  while(1) 
    {
      cout << "Doing orbital " << nmos+1 << "\n";    
      // first four lines line: Sym=, Ene=, Spin=, Occ=
      for (k = 0; k < 4; ++k) {
	if (fgets(buffer, LineLen, molden) == 0) {
	  printf("EOF after line %i while looking for MO %i\n", line, nmos+2); 
	  fclose(molden);
	  fclose(out);
	  exit(0);
	}
	line ++;
	fprintf(out, "%s", buffer);       
	// not an MO but something else follows (should not ever go here with Aces)
	if (strstr(buffer, "[")) {
	  bflag = 1;
	  break;
	}
      }
      if (bflag == 1)
	break;
      
      // read coefficients for each GTO
      for (k = 0; k < ngtos; ++k) {
	line ++;
	if (fgets(buffer, LineLen, molden) == 0)
	  {printf("Error reading line %i MO coefficient %i\n", line, k); exit(1);}  
	if (sscanf(buffer, "%*i %lf", &vec[k]) != 1)
	  {printf("Error (line %i) reading MO coefficient %i\n", line, k); exit(1);} 
      }

      // this is where the reordering is actually done
      int imo = 0;
      double z = 0;
      for (int ishell = 0; ishell < nshells; ++ishell) {
	switch (basis[ishell].l)
	  {
	  case 0 : 
	    imo += 1; 
	    break;
	  case 1 : 
	    imo += 3; 
	    break;
	  case 2 :
	    z = vec[imo+4];
	    vec[imo+4] = vec[imo+5];
	    vec[imo+5] = z;
	    imo += 6; 
	    break;
	  case 3 :
	    imo += 10;
	    break;
	  default:
	    cout << "This should never happen.\n";
	    exit(1);
	    break;
	  }
      }
      if (imo != ngtos) 
	{cout << "imo = " << imo << " should not happen.\n"; exit(4711);}


      
      // write coefficients for each GTO
      for (k = 0; k < ngtos; ++k) {
	fprintf(out,"%3i %19.10f\n", k+1, vec[k]);
      }

      nmos ++;


    }
}


